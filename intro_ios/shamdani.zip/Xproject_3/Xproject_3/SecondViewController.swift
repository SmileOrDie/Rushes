//
//  SecondViewController.swift
//  Xproject_3
//
//  Created by swift on 20/12/14.
//
//

    import UIKit
    import CoreLocation
    import MapKit
    
    class SecondViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {
        @IBOutlet weak var theMap: MKMapView!
        @IBOutlet weak var Controler: UISegmentedControl!
        
        var distant = 10000.0
        var manager:CLLocationManager!
        var myLocations: [CLLocation] = []
        var mapCenter = CLLocationCoordinate2D(latitude: 48.896582, longitude:  2.318497)
        
        override func viewDidLoad() {
            super.viewDidLoad()
            
     
            var mapCamera = MKMapCamera(lookingAtCenterCoordinate: mapCenter, fromEyeCoordinate: mapCenter, eyeAltitude: 500.0)
            theMap.setCamera(mapCamera, animated: false)
            theMap.mapType = MKMapType.Hybrid
            
            let annotation = MKPointAnnotation()
            annotation.setCoordinate(mapCenter)
            annotation.title = "Ecole 42"
            annotation.subtitle = "IT university"
            theMap.addAnnotation(annotation)

            }

        @IBAction func buttonPlus(sender: AnyObject) {
            distant *= 0.90
            var mapCamera = MKMapCamera(lookingAtCenterCoordinate: mapCenter, fromEyeCoordinate: mapCenter, eyeAltitude: distant)
            theMap.setCamera(mapCamera, animated: false)
        }
        @IBAction func buttonMoins(sender: AnyObject) {
            distant *= 1.10
            var mapCamera = MKMapCamera(lookingAtCenterCoordinate: mapCenter, fromEyeCoordinate: mapCenter, eyeAltitude: distant)
            theMap.setCamera(mapCamera, animated: false)
        }
        @IBAction func ChangeMap(sender: AnyObject) {
            if Controler.selectedSegmentIndex == 0 { theMap.mapType = MKMapType.Standard }
            if Controler.selectedSegmentIndex == 1 { theMap.mapType = MKMapType.Hybrid }
            if Controler.selectedSegmentIndex == 2 { theMap.mapType = MKMapType.Satellite }
        }
        
        let locationManager = CLLocationManager()
        
        @IBAction func findMyLocation(sender: AnyObject) {
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
            locationManager.requestWhenInUseAuthorization()
            locationManager.startUpdatingLocation()
            theMap.showsUserLocation = true

        }
        
        func locationManager(manager: CLLocationManager!, didUpdateLocations locations: [AnyObject]!) {
            mapCenter = CLLocationCoordinate2D(
                latitude: theMap.userLocation.coordinate.latitude,
                longitude: theMap.userLocation.coordinate.longitude
            )
            var mapCamera = MKMapCamera(lookingAtCenterCoordinate: mapCenter, fromEyeCoordinate: mapCenter, eyeAltitude: distant)
            theMap.setCamera(mapCamera, animated: true)
        }

        func locationManager(manager: CLLocationManager!, didFailWithError error: NSError!) {
            println("Error while updating location " + error.localizedDescription)
        }
        


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}
